# DBMS_project
Our project-an ecommerce database system for DBMS course
