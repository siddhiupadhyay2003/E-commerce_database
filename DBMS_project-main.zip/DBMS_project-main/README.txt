host of site: http://localhost/dbmspro/
xamp host: http://localhost/phpmyadmin/